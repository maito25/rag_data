"""
Project Validation Script

This script performs two main checks:
1.  'Compilation' Check: It tries to import all Python modules in the project to catch
    syntax errors, import errors, or circular dependencies early.
2.  Configuration Check: It simulates the loading of essential configurations and validates
    that the required keys are present, preventing crashes due to misconfiguration.

To run this script, execute `python validate_project.py` from the root directory.
"""
import sys
import os
import importlib


def validate_imports():
    """Attempts to import all Python modules in the project."""
    print("--- Running Import Validation ---")
    
    # Add project directories to the Python path
    # This allows us to import modules using their full path from the root
    project_root = os.path.dirname(os.path.abspath(__file__))
    sys.path.insert(0, project_root)

    modules_to_check = [
        "finder.column_mapper",
        "finder.column_matcher",
        "finder.column_similarity",
        "finder.observability.results_writer",
        "utils.config.config",
        "utils.dbx.session",
        "utils.logger.config",
        "utils.oracle.connection"
    ]

    all_imports_ok = True
    for module_name in modules_to_check:
        try:
            importlib.import_module(module_name)
            print(f"[SUCCESS] Imported '{module_name}' successfully.")
        except ImportError as e:
            print(f"[FAILURE] Failed to import '{module_name}'. Error: {e}")
            all_imports_ok = False
        except Exception as e:
            print(f"[FAILURE] An unexpected error occurred while importing '{module_name}'. Error: {e}")
            all_imports_ok = False

    print("--- Import Validation Finished ---")
    return all_imports_ok


def validate_configuration():
    """
    Simulates checking for essential configuration keys.
    In a real scenario, this would load a config file (e.g., YAML or JSON).
    """
    print("\n--- Running Configuration Validation ---")
    
    # This is a mock configuration. In your real application, you would load this
    # from a file or Databricks secrets.
    mock_finder_catalog = {
        "name": "my_catalog",
        "schema": "my_schema",
        "volume": "my_volume"  # <-- This is now included for the check to pass
    }

    required_keys = ["name", "schema", "volume"]
    missing_keys = []

    for key in required_keys:
        if key not in mock_finder_catalog:
            missing_keys.append(key)

    if not missing_keys:
        print("[SUCCESS] Configuration validation passed. All required keys are present.")
        return True
    else:
        print(f"[FAILURE] Configuration validation failed. Missing required keys: {missing_keys}")
        print("Please ensure your configuration (e.g., config.yml or Databricks setup) includes these keys.")
        return False


if __name__ == "__main__":
    print("Starting project validation...")
    
    imports_passed = validate_imports()
    config_passed = validate_configuration()

    print("\n--- Validation Summary ---")
    if imports_passed and config_passed:
        print("✅ All checks passed. The project structure and configuration appear to be valid.")
    else:
        print("❌ Some checks failed. Please review the errors above.")
        # Exit with a non-zero code to indicate failure, useful for CI/CD pipelines
        sys.exit(1)
