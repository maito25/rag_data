# Flujo Detallado del Acelerador para Diagrama de Procesos

Este documento detalla el flujo de ejecución del acelerador de validación de datos, paso a paso, para facilitar la creación de un diagrama de flujo (flowchart).

---

### **Fase 1: Inicialización y Configuración**

1.  **Inicio del Proceso:** El script `column_matcher_notebook.py` es ejecutado.
2.  **Cargar Configuración:** Se lee el archivo `utils/config/config.yml` para obtener parámetros clave:
    - `finder_catalog`: Catálogo, esquema y volumen de Databricks para almacenar resultados y datos temporales.
    - `output_mode`: Dónde guardar los informes (`deltalake`, `csv`, `text`).
    - `column_mappings_path` (Opcional): Ruta a un CSV con mapeos manuales de columnas.
    - Parámetros de ejecución como `sample_size` y `column_data_match_threshold`.
3.  **Inicializar Sesión de Spark:** Se obtiene o crea una `SparkSession` activa.
4.  **Instanciar Componentes Principales:**
    - Se crea una instancia de `ColumnContentMatcher`, que orquesta todo el proceso.
    - Dentro de `ColumnContentMatcher`, se inicializan:
        - `ColumnSimilarityCalculator`: El motor para calcular la similitud.
        - `ResultsWriter`: El componente para escribir los informes de resultados.

---

### **Fase 2: Carga y Muestreo de Datos (Por cada par de tablas Source/Target)**

1.  **Entrada de Tablas:** El proceso recibe una tabla de origen (`source_table`) y una de destino (`target_table`).
2.  **[Decisión] ¿El origen es Oracle?**
    - **SÍ:**
        - Se obtienen las credenciales de conexión a Oracle.
        - Se lee la tabla de Oracle usando JDBC (`read_oracle_table`).
        - **[Decisión] ¿Cuál es el `processing_mode`?**
            - **`deltalake`:** El DataFrame de Oracle se escribe como una tabla Delta temporal en la ruta especificada en `finder_catalog`. Luego, se lee de nuevo como un DataFrame de Delta. **(Ruta preferida para desacoplar y optimizar).**
            - **`direct`:** El DataFrame se mantiene como una conexión directa a través de JDBC. **(Más simple, pero puede ser menos performante).**
            - **`memory`:** El DataFrame se convierte a un DataFrame de Pandas y luego de vuelta a un DataFrame de Spark. **(Rápido para muestras pequeñas, pero riesgo de error OutOfMemory).**
    - **NO:** (El origen es una tabla de Databricks)
        - Se lee la tabla directamente con `spark.table(source_table)`.
3.  **Normalizar Nombres de Columnas:** Se convierten todos los nombres de columna de los DataFrames de origen y destino a mayúsculas para evitar inconsistencias.
4.  **Muestreo de Datos:** Se extrae una muestra de los DataFrames de origen y destino.
    - **[Decisión] ¿Se proveyeron `key_columns` (columnas clave para ordenamiento)?**
        - **SÍ:** Se ordena el DataFrame por esas columnas (`orderBy`) y se toman los primeros N registros (`limit(sample_size)`). Esto crea una muestra determinista.
        - **NO:** Se toma una muestra aleatoria usando el método `.sample()`. Esto es menos predecible pero útil cuando no hay claves claras.

---

### **Fase 3: Comparación de Columnas (Ejecución en Paralelo)**

1.  **Generar Pares de Comparación:** Se crea una lista de todos los posibles pares de columnas entre la tabla de origen y la de destino (ej. `(origen_col_A, destino_col_1)`, `(origen_col_A, destino_col_2)`, etc.). Si se proporcionó un archivo de mapeo, solo se usarán esos pares.
2.  **Iterar y Calcular Similitud (en paralelo por Spark):** Para cada par de columnas:
    - **[Decisión] ¿Son los tipos de datos compatibles?** (Ej. numérico con numérico, fecha con fecha). Los tipos de texto son compatibles con casi todo, ya que los otros se pueden convertir a texto.
        - **SÍ:** Se procede al cálculo.
        - **NO:** Se salta el par.
    - Se invoca a `ColumnSimilarityCalculator.calculate_column_similarity_from_samples()`.
    - **Lógica Interna del Calculador:**
        - **a. Similitud de Jaccard (para todos los tipos):**
            - Se obtienen los valores únicos de cada columna de la muestra.
            - Se calcula: `(tamaño de la intersección de valores) / (tamaño de la unión de valores)`.
            - El resultado es un score entre 0 y 1.
        - **b. [Decisión] ¿Ambas columnas son numéricas?**
            - **SÍ:**
                - Se calculan estadísticas para ambas: `min`, `max`, `media`, `desviación estándar`.
                - Se calcula una **Similitud de Distribución** comparando qué tan parecidas son estas estadísticas entre las dos columnas.
                - El `overall_score` final es un promedio ponderado de la Similitud de Jaccard y la de Distribución.
            - **NO:**
                - El `overall_score` es directamente la Similitud de Jaccard.

---

### **Fase 4: Agregación de Resultados y Reporte**

1.  **Recolectar Resultados:** Se recopilan los `overall_score` de todos los pares de columnas comparados.
2.  **Filtrar por Umbral:** Se descartan todos los pares cuyo score de similitud sea inferior al `column_data_match_threshold` definido en la configuración.
3.  **Estructurar Informe:** Los resultados finales se organizan en un formato claro, mostrando:
    - Columna Origen
    - Columna Destino Propuesta
    - Score de Similitud (Jaccard, Distribución, General)
    - Estadísticas (si aplica)
4.  **Escribir Resultados:** Se utiliza el `ResultsWriter` para guardar el informe final.
    - **[Decisión] ¿Cuál es el `output_mode`?**
        - **`deltalake`:** Se escribe el DataFrame del informe en una tabla Delta en la ruta definida en `finder_catalog`.
        - **`csv`:** Se guarda como un archivo CSV.
        - **`text`:** Se imprime el resultado en la consola o log.

---

### **Fase 5: Fin del Proceso**

1.  **Finalización:** El script termina su ejecución.
