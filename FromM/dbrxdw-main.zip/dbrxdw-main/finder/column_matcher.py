"""
Optimized Column Content Matcher

This module provides functionality to match columns between tables based on their data content.
This version is heavily optimized to run efficiently on Spark and complies with strict code quality rules.
"""
import sys
from pathlib import Path

sys.path.append(str(Path(__file__).parent.parent))

import time
from typing import Dict, List, Tuple, Optional, Any, Literal
from pyspark.sql import DataFrame, SparkSession, Row
from pyspark.sql import functions as F
from pyspark.sql.types import (
    IntegerType, LongType, FloatType, DoubleType, DecimalType,
    TimestampType, DateType, StringType, DataType, NumericType
)

from utils.logger import get_finder_logger
from .column_similarity import ColumnSimilarityCalculator
from utils.oracle import get_oracle_connection_properties, read_oracle_table
from observability.results_writer import ResultsWriter, OutputMode
from .column_mapper import ColumnMapper

ProcessingMode = Literal['direct', 'cache']

class ColumnContentMatcher:
    """
    A class to identify similar columns across tables based on data content.
    Optimized for performance and adherence to strict coding standards.
    """

    def __init__(self, spark: SparkSession, finder_catalog: Dict[str, str], run_timestamp: str, output_mode: OutputMode = 'text', column_mappings_path: Optional[str] = None):
        self.logger = get_finder_logger(level="INFO", include_debug=True)
        start_time = time.time()
        self.logger.info("Initializing Optimized ColumnContentMatcher...")
        self.spark = spark
        self.similarity_calculator = ColumnSimilarityCalculator(self.spark)
        self.finder_catalog = finder_catalog
        self.run_timestamp = run_timestamp
        self.output_mode = output_mode
        
        self.column_mapper = ColumnMapper(column_mappings_path) if column_mappings_path else None
        if self.column_mapper:
            self.logger.info(f"Column mappings loaded from: {column_mappings_path}")
        else:
            self.logger.info("No column mappings provided - will use automatic column matching")
        
        self.results_writer = ResultsWriter(
            spark=self.spark,
            catalog=finder_catalog["name"],
            schema=finder_catalog["schema"],
            volume=finder_catalog["volume"],
            run_timestamp=run_timestamp,
            output_mode=output_mode
        )
        elapsed = time.time() - start_time
        self.logger.info(f"Optimized ColumnContentMatcher initialized successfully in {elapsed:.2f}s")

    def _normalize_columns(self, columns: List[str]) -> List[str]:
        return [col.upper() for col in columns]

    def _load_source_dataframe(
        self,
        source_table: str,
        source_type: str,
        processing_mode: ProcessingMode,
        sample_size: int,
        partition_column: Optional[str] = None,
        lower_bound: Optional[int] = None,
        upper_bound: Optional[int] = None,
        num_partitions: Optional[int] = None,
        source_key_columns: Optional[List[str]] = None,
    ) -> DataFrame:
        self.logger.info(f"Loading source table: {source_table} with processing mode: {processing_mode}")
        if source_type == "oracle":
            oracle_props = get_oracle_connection_properties()
            
            source_df = read_oracle_table(
                self.spark,
                source_table,
                oracle_props,
                sample_size=sample_size,
                partition_column=partition_column,
                lower_bound=lower_bound,
                upper_bound=upper_bound,
                num_partitions=num_partitions,
                order_by_columns=source_key_columns
            )
            
            if processing_mode == 'cache':
                self.logger.info("Using 'cache' mode: Caching JDBC DataFrame for performance.")
                # Caching the DataFrame will store it in memory/disk after the first action.
                # This avoids re-reading from Oracle on subsequent operations.
                source_df = source_df.cache()
                                  
        else: # databricks source
            source_df = self.spark.table(source_table)

        # Normalize column names to uppercase
        return source_df.select(*[F.col(c).alias(c.upper()) for c in source_df.columns])

    def _calculate_stats_in_one_pass(self, df: DataFrame, df_name: str) -> Dict[str, Any]:
        """Calculate all required statistics for a DataFrame in a single pass to optimize performance."""
        self.logger.info(f"Calculating statistics for {df_name} in a single pass...")
        
        exprs = [F.count(F.lit(1)).alias("total_rows")]
        columns_to_profile = [(f.name, f.dataType) for f in df.schema.fields]

        for col_name, col_type in columns_to_profile:
            exprs.append(F.sum(F.when(F.col(col_name).isNull(), 1).otherwise(0)).alias(f"{col_name}_nulls"))
            exprs.append(F.approx_count_distinct(F.col(col_name)).alias(f"{col_name}_distinct"))
            
            if isinstance(col_type, NumericType):
                exprs.append(F.min(F.col(col_name)).alias(f"{col_name}_min"))
                exprs.append(F.max(F.col(col_name)).alias(f"{col_name}_max"))
                exprs.append(F.mean(F.col(col_name)).alias(f"{col_name}_mean"))
                exprs.append(F.stddev(F.col(col_name)).alias(f"{col_name}_stddev"))

        # Execute all aggregations in one go. .collect() is safe here as it returns a single row.
        stats_row = df.agg(*exprs).collect()[0]
        self.logger.info(f"Successfully calculated stats for {df_name}.")
        
        # Restructure the single row result into a nested dictionary for easier access
        results = {"total_rows": stats_row["total_rows"], "columns": {}}
        for col_name, col_type in columns_to_profile:
            results["columns"][col_name] = {
                "null_count": stats_row[f"{col_name}_nulls"],
                "distinct_count": stats_row[f"{col_name}_distinct"],
                "numeric_stats": {}
            }
            if isinstance(col_type, NumericType):
                results["columns"][col_name]["numeric_stats"] = {
                    "min": stats_row[f"{col_name}_min"],
                    "max": stats_row[f"{col_name}_max"],
                    "mean": stats_row[f"{col_name}_mean"],
                    "stddev": stats_row[f"{col_name}_stddev"],
                }
        return results

    def find_matching_columns_parallel(
        self,
        source_table: str,
        target_table: str,
        source_df: DataFrame,
        target_df: DataFrame,
        source_stats: Dict[str, Any],
        target_stats: Dict[str, Any],
        column_data_match_threshold: float = 0.9,
        column_mappings: Optional[List[Tuple[str, str]]] = None,
    ) -> Dict[str, Dict[str, float]]:
        """Finds matching columns between two DataFrames using pre-calculated stats and optimized similarity checks."""
        self.logger.info(f"Finding matching columns between {source_table} and {target_table}...")
        start_time = time.time()

        source_columns = list(source_stats["columns"].keys())
        target_columns = list(target_stats["columns"].keys())
        source_schema_map = {f.name: f.dataType for f in source_df.schema.fields}

        # 1. Identify candidate pairs based on mappings or type compatibility
        if column_mappings:
            candidate_pairs = column_mappings
            self.logger.info(f"Using {len(candidate_pairs)} provided column mappings.")
        else:
            target_schema_map = {f.name: f.dataType for f in target_df.schema.fields}
            candidate_pairs = [
                (s_col, t_col)
                for s_col in source_columns
                for t_col in target_columns
                if self.similarity_calculator.are_types_compatible(source_schema_map.get(s_col), target_schema_map.get(t_col))
            ]
            self.logger.info(f"Generated {len(candidate_pairs)} candidate pairs based on compatible data types.")

        # 2. Score pairs based on pre-calculated metadata statistics (cheap to compute)
        scored_pairs = []
        for s_col, t_col in candidate_pairs:
            s_stats = source_stats['columns'][s_col]
            t_stats = target_stats['columns'][t_col]
            
            metadata_similarity = self.similarity_calculator.calculate_metadata_similarity(s_stats, t_stats)
            
            # Keep pairs with some minimal level of metadata similarity
            if metadata_similarity > 0.1: 
                scored_pairs.append(((s_col, t_col), metadata_similarity))

        # Sort by metadata score to prioritize more likely matches for content analysis
        scored_pairs.sort(key=lambda x: x[1], reverse=True)
        self.logger.info(f"Filtered down to {len(scored_pairs)} promising pairs based on metadata similarity.")

        # 3. Calculate content similarity (Jaccard) for the most promising pairs
        final_results = {}
        # Limit Jaccard to top N candidates to control cost, e.g., top 100
        pairs_for_content_check = [p[0] for p in scored_pairs[:100]]

        if pairs_for_content_check:
            content_similarities = self.similarity_calculator.calculate_jaccard_for_multiple_pairs(
                source_df, target_df, pairs_for_content_check
            )

            # 4. Combine scores and filter by final threshold
            for (s_col, t_col), meta_score in scored_pairs:
                if (s_col, t_col) in content_similarities:
                    jaccard_score = content_similarities[(s_col, t_col)]
                    # Combine scores (e.g., weighted average)
                    overall_score = 0.4 * meta_score + 0.6 * jaccard_score

                    if overall_score >= column_data_match_threshold:
                        if s_col not in final_results:
                            final_results[s_col] = {}
                        final_results[s_col][t_col] = {
                            "overall": overall_score,
                            "metadata": meta_score,
                            "jaccard": jaccard_score
                        }
                        self.logger.info(f"  ✓ Match found: {s_col} -> {t_col} (Score: {overall_score:.4f})")

        elapsed = time.time() - start_time
        self.logger.info(f"Column matching finished in {elapsed:.2f}s. Found {sum(len(v) for v in final_results.values())} matches.")
        return final_results

    def find_subset_tables(
        self,
        source_table: str,
        target_tables: List[str],
        source_type: str = "oracle",
        processing_mode: ProcessingMode = "cache",
        sample_size: int = 1000,
        partition_column: Optional[str] = None,
        lower_bound: Optional[int] = None,
        upper_bound: Optional[int] = None,
        num_partitions: Optional[int] = None,
        source_key_columns: Optional[List[str]] = None,
        target_key_columns: Optional[List[str]] = None, # Note: target_key_columns is not used in this optimized version
        column_data_match_threshold: float = 0.9,
        table_subset_threshold: float = 0.9,
    ) -> List[Dict[str, Any]]:
        self.logger.info(f"Starting subset table finding for source: {source_table}")
        self.logger.info(f"Processing mode: {processing_mode}, Sample size: {sample_size}")
        start_time = time.time()

        # 1. Load source DataFrame and calculate its stats once.
        source_df = self._load_source_dataframe(
            source_table=source_table, source_type=source_type, processing_mode=processing_mode,
            sample_size=sample_size, partition_column=partition_column, lower_bound=lower_bound,
            upper_bound=upper_bound, num_partitions=num_partitions, source_key_columns=source_key_columns
        )
        # Trigger an action to cache the source_df if mode is 'cache'
        if source_df.is_cached:
            source_df.count() # Use a light action like count() to trigger cache
        
        self.logger.info(f"Source table '{source_table}' loaded. Calculating stats...")
        source_stats = self._calculate_stats_in_one_pass(source_df, source_table)
        source_total_rows = source_stats.get("total_rows", 0)
        self.logger.info(f"Source table '{source_table}' has {source_total_rows} rows. Stats calculated.")

        all_results = []
        for target_table in target_tables:
            self.logger.info(f"\n{'='*40}\nComparing '{source_table}' with '{target_table}'\n{'='*40}")
            target_df = None # ensure target_df is defined for finally block
            try:
                # 2. Load target table and calculate its stats.
                target_df = self.spark.table(target_table).select(*[F.col(c).alias(c.upper()) for c in self.spark.table(target_table).columns])
                target_df.cache() # Cache target df for stats and similarity
                target_stats = self._calculate_stats_in_one_pass(target_df, target_table)
                
                column_mappings = None
                if self.column_mapper:
                    try:
                        column_mappings = self.column_mapper.get_mapping(source_table, target_table)
                        self.logger.info(f"Using {len(column_mappings)} pre-defined column mappings for {target_table}.")
                    except ValueError as e:
                        self.logger.warning(f"Could not get column mappings for {target_table}: {e}")

                # 3. Find matching columns using the optimized parallel function.
                matches = self.find_matching_columns_parallel(
                    source_table=source_table, target_table=target_table,
                    source_df=source_df, target_df=target_df,
                    source_stats=source_stats, target_stats=target_stats,
                    column_data_match_threshold=column_data_match_threshold,
                    column_mappings=column_mappings
                )

                # 4. Analyze results and check if it qualifies as a subset table.
                num_source_cols = len(source_stats["columns"])
                num_matched_cols = len(matches)
                match_ratio = num_matched_cols / num_source_cols if num_source_cols > 0 else 0

                is_subset = match_ratio >= table_subset_threshold

                result_details = {
                    "source_table": source_table,
                    "target_table": target_table,
                    "is_subset": is_subset,
                    "column_match_ratio": match_ratio,
                    "matched_columns_count": num_matched_cols,
                    "source_columns_count": num_source_cols,
                    "matches": matches
                }
                all_results.append(result_details)
                
                self.logger.info(f"Comparison with '{target_table}' complete. Match ratio: {match_ratio:.2%}. Is subset: {is_subset}")

            except Exception as e:
                self.logger.error(f"Error processing target table {target_table}: {e}", exc_info=True)
                all_results.append({
                    "source_table": source_table,
                    "target_table": target_table,
                    "error": str(e)
                })
            finally:
                # Unpersist the target dataframe to free up memory for the next iteration
                if target_df and target_df.is_cached:
                    target_df.unpersist()
                    self.logger.info(f"Unpersisted target table '{target_table}'.")

        # Unpersist source df after all comparisons are done
        if source_df.is_cached:
            source_df.unpersist()
            self.logger.info(f"Unpersisted source table '{source_table}'.")
            
        elapsed = time.time() - start_time
        self.logger.info(f"Subset table finding finished in {elapsed:.2f}s.")
        
        # Save results to Delta tables
        self.logger.info("\nSaving analysis results to Delta tables...")
        self.results_writer.save_analysis_results(all_results)
        
        return all_results
