# Databricks notebook source
# MAGIC %md
# MAGIC # Table Relationship Finder
# MAGIC
# MAGIC This tool finds relationships between tables by analyzing actual data content rather than just metadata.
# MAGIC Useful for data migrations where tables have been renamed or restructured.
# MAGIC
# MAGIC ## How it works
# MAGIC 1. Load predefined column mappings from CSV (optional but recommended for performance)
# MAGIC 2. Compare data content between source and target tables
# MAGIC 3. Calculate similarity scores for matching columns
# MAGIC 4. Generate relationship analysis report
# MAGIC
# MAGIC ## How to Run
# MAGIC 1. Upload the .csv with the column mapping
# MAGIC 2. Change the configuration options in cell 2
# MAGIC 3. Run all cells below
# MAGIC
# MAGIC
# MAGIC ##### CSV Mapping File Format
# MAGIC
# MAGIC The CSV file should have these 8 columns:
# MAGIC - source_catalog, source_schema, source_table, source_column
# MAGIC - target_catalog, target_schema, target_table, target_column
# MAGIC


# COMMAND ----------
# MAGIC %md
# MAGIC ---
# MAGIC ### 1. General Configuration
# MAGIC **Set up table names, paths, and credentials here.**
# MAGIC ---

# COMMAND ----------
# General configuration
source_table = "ods.md_destipogarantia"  # Oracle source table (SCHEMA.TABLE)
candidate_tables = ["catalog_lhcl_desa_bcp.bcp_udv_int.m_destipogarantia", "catalog_lhcl_desa_bcp.bcp_udv_int.another_table"]  # List of Databricks tables
column_mapping_csv_name = "example_column_mappings.csv" # Optional: CSV with known column mappings. Set to None to disable.

# Source table configuration (Oracle)
# DANGER: Do not use plaintext passwords. Use Databricks Secrets.
# Example: oracle_password = dbutils.secrets.get(scope="your_scope", key="oracle_password_key")
oracle_user = "t37400"
oracle_password = "REPLACE_WITH_DBUTILS_SECRET"
oracle_connection_string = "130.1.22.91:1521/BCPDW3"

# Optional: For parallel reading from Oracle (for very large tables)
source_key_columns = ["tipgarantia"] # Columns to order source data by, important for consistent sampling
oracle_partition_column = None # e.g., "ID_COLUMN"
oracle_lower_bound = None      # e.g., 1
oracle_upper_bound = None      # e.g., 1000000
oracle_num_partitions = None   # e.g., 10

# COMMAND ----------
# MAGIC %md
# MAGIC ---
# MAGIC ### 2. Analysis Thresholds & Parameters
# MAGIC **Tune the sensitivity of the analysis here.**
# MAGIC ---

# COMMAND ----------
# Analysis parameters
sample_size = 10000  # Number of rows to sample from each table for analysis.

# Thresholds that define the business logic for matching
column_data_match_threshold = 0.85  # (0.0 to 1.0) Minimum combined score for two columns to be considered a match.
table_column_match_ratio = 0.50   # (0.0 to 1.0) Minimum percentage of source columns that must find a match for the table to be considered related.
subset_threshold = 0.95           # (0.0 to 1.0) Minimum percentage of data overlap to classify a table as a subset.

# Technical parameters
processing_mode = "cache"  # "cache" or "no_cache". Cache is faster for multiple candidates but uses more memory.
output_mode = "delta"      # "delta" to save results to tables, "display" for logs only.

# COMMAND ----------
# MAGIC %md
# MAGIC ---
# MAGIC ### 3. Setup & Imports
# MAGIC *(No changes needed in this section)*
# MAGIC ---

# COMMAND ----------
import os
import sys
import time
import yaml
from pathlib import Path

# Add project root to sys.path to allow module imports
try:
    project_root = str(Path().cwd().parent)
    if project_root not in sys.path:
        sys.path.append(project_root)
except NameError:
    project_root = os.path.abspath('.')

from finder.column_matcher import ColumnContentMatcher
from utils.logger import get_finder_logger
from utils.dbx.session import initialize_dbx_session
from utils.config.config import load_config

logger = get_finder_logger(level="DEBUG", include_debug=True)
spark = initialize_dbx_session()

if column_mapping_csv_name:
    mapping_file_path = os.path.join(project_root, "finder", column_mapping_csv_name)
else:
    mapping_file_path = None

config = load_config(os.path.join(project_root, 'config.yaml'))
finder_config = config['finder_config']

finder_config['oracle']['user'] = oracle_user
finder_config['oracle']['password'] = oracle_password
finder_config['oracle']['connection_string'] = oracle_connection_string

# COMMAND ----------
# MAGIC %md
# MAGIC ---
# MAGIC ### 4. Analysis Logic
# MAGIC *(No changes needed in this section)*
# MAGIC ---

# COMMAND ----------
def run_analysis():
    """Main function to execute the table relationship analysis."""
    matcher = ColumnContentMatcher(
        spark=spark,
        config=finder_config,
        logger=logger,
        predefined_mappings_path=mapping_file_path
    )
    
    results = matcher.find_subset_tables(
        source_table=source_table,
        target_tables=candidate_tables,
        source_key_columns=source_key_columns,
        source_type="oracle",
        sample_size=sample_size,
        partition_column=oracle_partition_column,
        lower_bound=oracle_lower_bound,
        upper_bound=oracle_upper_bound,
        num_partitions=oracle_num_partitions,
        column_data_match_threshold=column_data_match_threshold,
        table_column_match_ratio=table_column_match_ratio,
        subset_threshold=subset_threshold,
        processing_mode=processing_mode,
        output_mode=output_mode
    )
    return results, matcher

def print_results(results, matcher):
    """Prints the analysis results in a professional, human-readable format."""
    if not results:
        matcher.logger.info("No relationships were found for any candidate tables.")
        return

    matcher.logger.info(f"\n{'='*80}")
    matcher.logger.info(f"                  FINAL ANALYSIS SUMMARY")
    matcher.logger.info(f"{'='*80}")
    
    for table, info in results.items():
        relationship = info.get('relationship', 'Error')
        match_ratio = info.get('match_ratio', 0)
        
        matcher.logger.info(f"\n--- Target Table: {table} ---")
        matcher.logger.info(f"    --> Verdict: {relationship}")
        matcher.logger.info(f"    Column Match Ratio: {match_ratio:.2%} (Threshold: {table_column_match_ratio:.2%})")

        if 'Error' not in relationship:
            matcher.logger.info(f"    Source Row Count: {info.get('source_row_count', 0):,}")
            matcher.logger.info(f"    Target Row Count: {info.get('candidate_row_count', 0):,}")
            matcher.logger.info(f"    Subset Score (Source in Target): {info.get('avg_source_in_target', 0):.2%} (Threshold: {subset_threshold:.2%})")
            
            if info.get("matching_columns"):
                matcher.logger.info("    Column Matches Found:")
                for src_col, matches in info["matching_columns"].items():
                    for tgt_col, metrics in matches.items():
                        matcher.logger.info(f"      - {src_col} -> {tgt_col} (Score: {metrics['overall']:.2%})")
            else:
                matcher.logger.info("    No individual column matches found.")
    matcher.logger.info(f"\n{'='*80}")

# COMMAND ----------
# MAGIC %md
# MAGIC ---
# MAGIC ### 5. Execution
# MAGIC *(Run this cell to start the process)*
# MAGIC ---

# COMMAND ----------
if __name__ == "__main__":
    analysis_results, matcher_instance = run_analysis()
    print_results(analysis_results, matcher_instance)
