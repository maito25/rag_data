# Presentación: Acelerador de Migración y Validación de Datos en Databricks

---

## Diapositiva 1: Título

**Acelerador de Validación de Datos para Migraciones de Oracle a Databricks**

*Una herramienta para reducir a la mitad el tiempo de validación de datos y garantizar la integridad en migraciones de Data Warehouse.* 

**Audiencia:** Foro de Arquitectura, Líderes Técnicos, Squads de Datos.

---

## Diapositiva 2: El Desafío (Situación Actual - AS-IS)

**La Validación Manual: Un Proceso Lento y Propenso a Errores**

- **Proceso Actual:** Los custodios de datos invierten horas en validar manualmente que los datos migrados de un Oracle Data Warehouse a un Databricks Lakehouse sean íntegros.
- **Alta Carga Operativa:** El trabajo requiere la ejecución de múltiples queries complejas en origen y destino para comparar esquemas, conteos y datos.
- **Esfuerzo Manual:** Todo el proceso es manual, repetitivo y consume un tiempo valioso que podría dedicarse a tareas de mayor impacto.
- **Dependencia de Expertos:** Requiere un conocimiento profundo tanto de Oracle como de Databricks, limitando la capacidad de otros equipos para realizar validaciones.

**El resultado: un cuello de botella en los proyectos de migración.**

---

## Diapositiva 3: La Solución (Situación Futura - TO-BE)

**Automatización Inteligente para una Migración Confiable**

- **Objetivo Principal:** Reducir el tiempo de validación de datos en al menos un 50%, liberando a los custodios para que se centren en actividades estratégicas.
- **Capacidad Clave:** El acelerador identifica automáticamente qué columnas de una tabla de origen en Oracle corresponden a qué columnas en las tablas de destino en Databricks, basándose en el contenido de los datos, no solo en los nombres.
- **Democratización:** Permite que cualquier squad, con mínima configuración, pueda ejecutar validaciones de integridad de datos de forma autónoma.

**El resultado: migraciones más rápidas, confiables y escalables.**

---

## Diapositiva 4: ¿Cómo Funciona? La Tecnología Detrás del Acelerador

**Un Enfoque Basado en el Análisis de Contenido y Estadísticas**

1.  **Entrada Simple:** El usuario solo necesita proporcionar una tabla de origen (Oracle) y una o más tablas de destino candidatas (Databricks).
2.  **Muestreo Inteligente:** La herramienta toma una muestra configurable de datos de cada tabla para realizar una comparación eficiente sin necesidad de procesar terabytes de información.
3.  **Similitud de Contenido (Índice de Jaccard):** Para cada par de columnas, calcula el **Índice de Jaccard**, que mide la similitud entre los conjuntos de datos distintos. Un valor alto indica una gran superposición de datos.
4.  **Análisis de Distribución (Para Números):** Si las columnas son numéricas, el acelerador va un paso más allá y compara sus distribuciones estadísticas (mínimo, máximo, media, desviación estándar) para una validación más robusta.
5.  **Umbral Configurable:** Un umbral de similitud (ej. 90%) permite al usuario definir qué tan estricta debe ser la coincidencia para considerar dos columnas como un par válido.

---

## Diapositiva 5: Características Principales y Flexibilidad

**Una Herramienta Adaptable y Robusta**

- **Mapeo Automático de Columnas:** Descubre relaciones entre columnas incluso si tienen nombres diferentes, un problema común en las migraciones.
- **Validación Cruzada de Datos:** No solo compara metadatos, sino el contenido real, garantizando que los valores se hayan transferido correctamente.
- **Modos de Procesamiento Flexibles:**
    - **`deltalake` (Recomendado):** Persiste temporalmente los datos de Oracle en Delta para un rendimiento óptimo en Spark.
    - **`direct`:** Procesa los datos directamente desde la conexión JDBC de Oracle.
    - **`memory`:** Carga las muestras en memoria para ejecuciones rápidas con volúmenes de datos pequeños.
- **Observabilidad y Auditoría:** Guarda un informe detallado de cada ejecución en una tabla Delta para un seguimiento y auditoría completos. El resultado final se ve así:

  **Ejemplo de Tabla de Resultados en Delta:**

| source_column | target_column   | jaccard_similarity | overall_similarity | status |
|---------------|-----------------|--------------------|--------------------|--------|
| `ID_CLIENTE`  | `CUSTOMER_ID`   | 0.99               | 0.98               | MATCH  |
| `FECHA_ALTA`  | `CREATION_DATE` | 0.95               | 0.96               | MATCH  |
| `DIRECCION`   | `ADDRESS_LINE1` | 0.75               | 0.75               | REVIEW |
| `IMPORTE_TXN` | `TRANSACTION_AMT`| 0.92               | 0.94               | MATCH  |

---

## Diapositiva 6: Arquitectura y Flujo de Alto Nivel

**Un Proceso Orquestado en 4 Pasos**

1.  **Configurar:** Se definen los parámetros de la ejecución en un archivo `config.yml` (tablas, umbrales, tamaño de muestra, modo de procesamiento).
2.  **Conectar y Muestrear:** El acelerador se conecta a Oracle y Databricks, y extrae las muestras de datos de manera eficiente.
3.  **Comparar en Paralelo:** Utilizando el poder de Spark, se comparan todos los pares de columnas candidatas en paralelo, calculando los scores de similitud.
4.  **Generar Reporte:** Se filtran los resultados que superan el umbral de similitud y se genera un informe final, que se almacena en una tabla Delta para su consulta.

**¿Interesado en usar o contribuir a esta solución? ¡Hablemos!**
