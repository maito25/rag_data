# Databricks Table Relationship Finder

## 1. Overview

This project is a robust and scalable solution for discovering relationships between Oracle source tables and Databricks target tables. Instead of relying on metadata, it analyzes the actual data content to find matches, making it ideal for complex data migration and validation scenarios.

The entire analysis is driven from a single, well-documented Databricks notebook: `finder/column_matcher_notebook.py`.

## 2. Key Features

-   **Robust Content-Based Matching**: Discovers relationships even when table and column names have changed.
-   **Configurable Business Logic**: Easily tune analysis sensitivity using clear thresholds in the notebook for column and table matches.
-   **Detailed Logging & Performance Metrics**: Professional, step-by-step logging provides full transparency into the analysis process and timings for each major step.
-   **Error Resilience**: The process is designed to handle errors gracefully, ensuring that a failure in analyzing one table does not stop the entire job.
-   **Secure Credential Management**: Strong recommendation and clear instructions for using Databracks Secrets to handle Oracle credentials securely.
-   **Pre-defined Mapping Support**: Optionally provide a CSV of known column mappings to guide the analysis and ensure critical columns are always compared.

## 3. Project Structure

```
dbrxdw-main/
├── finder/                           # Core analysis logic
│   ├── column_matcher.py             # The main analysis engine class
│   ├── column_matcher_notebook.py    # The main entry point for execution
│   └── example_column_mappings.csv   # Example of a predefined mapping file
├── utils/                            # Shared utilities
│   ├── config/                       # Configuration loader
│   ├── dbx/                          # Databricks session helper
│   └── logger/                       # Standardized logger
├── config.yaml                       # Base configuration file (can be overridden by notebook)
├── validate_project.py               # Script to validate imports and configuration
└── README.md                         # This file
```

## 4. How to Run

Execution is simple and is done entirely within the Databricks environment.

### Step 1: Upload Project and Manage Dependencies

Upload the entire project folder to a Databricks Repo. Databricks will automatically detect the `requirements.txt` file and install the necessary libraries (`oracledb` and `PyYAML`) for the notebook session. There is no need to manually run any `%pip install` commands.

### Step 2: Configure the Notebook

Open the `finder/column_matcher_notebook.py` notebook. All configuration is done in the first two cells:

1.  **Cell 1: General Configuration**
    -   `source_table`: The Oracle source table (`SCHEMA.TABLE`).
    -   `candidate_tables`: A Python list of Databricks tables to compare against (`catalog.schema.table`).
    -   `oracle_user`, `oracle_password`, `oracle_connection_string`: Your Oracle credentials. **IMPORTANT**: Replace the placeholder password with a call to Databricks Secrets, like `dbutils.secrets.get(scope="your_scope", key="oracle_pwd")`.

2.  **Cell 2: Analysis Thresholds & Parameters**
    -   `column_data_match_threshold`: Minimum score (0.0 to 1.0) for two columns to be considered a match. Default is `0.85`.
    -   `table_column_match_ratio`: Minimum percentage of columns that must match for a table to be related. Default is `0.50`.
    -   `subset_threshold`: Minimum data overlap percentage to classify a table as a subset. Default is `0.95`.

### Step 3: Run the Notebook

Run all cells in the notebook. The output will be printed in the final cell's log, providing a clear summary of the findings. If `output_mode` is set to `"delta"`, detailed results will also be saved to Delta tables in the catalog defined in `config.yaml`.

## 5. Project Validation

To ensure the project is set up correctly before a long run, you can use the `validate_project.py` script.

### How to Run Validation

In a terminal with the Databricks CLI configured or in a web terminal, navigate to the project root and run:

```bash
python validate_project.py
```

### Understanding the Output

-   **[SUCCESS]**: Indicates that a module was imported correctly or that the configuration is valid.
-   **[FAILURE]**: Indicates an issue.

**Expected Failures in a Local Environment**: When you run this script on your local machine (not in Databricks), you will see `[FAILURE]` messages for modules like `pyspark` and `databricks-sdk`. **This is normal and expected**, as these libraries are provided by the Databricks runtime environment and are typically not installed locally. The key is to ensure there are no other unexpected import errors and that the Configuration Validation passes.
